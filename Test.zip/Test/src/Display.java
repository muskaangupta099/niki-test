import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;

public class Display {


	AndroidDriver driver;
	
	@Test(priority=1)
	public void test() throws MalformedURLException, InterruptedException
	{
					File app = new File("C:\\Users\\Muskaan\\Desktop\\Niki\\app-test-apk.apk");
					
		 
					DesiredCapabilities capabilities = new DesiredCapabilities();
					capabilities.setCapability("deviceName", "ZY223NW58Z");
					capabilities.setCapability("platformVersion", "7.0");
					capabilities.setCapability("platformName", "Android");
					capabilities.setCapability("app", app.getAbsolutePath());
					capabilities.setCapability("appPackage", "com.techbins.niki.beta");
					capabilities.setCapability("appActivity","com.techbins.niki.SplashActivity");
					
		 
					driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					
	}
					
					
					@Test(priority=2)
					public void test1() throws InterruptedException
					{
						 new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.id("com.techbins.niki.beta:id/edtTxtPhone")));
						//driver.findElementByClassName("TextInputLayout").sendKeys("8851946938");
						driver.findElementById("com.techbins.niki.beta:id/edtTxtPhone").sendKeys("9991169027");
						 new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.id("com.techbins.niki.beta:id/btnSubmit")));
						driver.findElement(By.id("com.techbins.niki.beta:id/btnSubmit")).click();
						
						
					}
					
					
					@Test(priority=3)
					public void wrongnumber() throws InterruptedException
					{
						new WebDriverWait(driver, 20).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//android.widget.TextView[@index=2]")));
						driver.findElementByXPath("//android.widget.TextView[@index=2]").click();
						driver.findElementById("com.techbins.niki.beta:id/edtTxtPhone").clear();
						driver.findElementById("com.techbins.niki.beta:id/edtTxtPhone").sendKeys("8851946937");
						driver.findElement(By.id("com.techbins.niki.beta:id/btnSubmit")).click();
						
		
					}
					
					
					
					@Test(priority=4)
					public void completeregistration() throws InterruptedException
					{
						driver.findElementById("com.techbins.niki.beta:id/editTxtName").sendKeys("MuskaanGupta");
						driver.findElementById("com.techbins.niki.beta:id/editTxtEmail").click();
						if(driver.findElements(By.xpath("//android.widget.CheckedTextView")).size()>0)
						{
							Thread.sleep(5000);
							List<WebElement> a= driver.findElements(By.xpath("//android.widget.CheckedTextView"));
							for(WebElement a1:a)
							{
								a1.click();
								Thread.sleep(3000);
								driver.findElement(By.xpath("//android.widget.Button[@index=1]")).click();
								break;
							}
						}
						else{
						driver.findElementById("com.techbins.niki.beta:id/editTxtEmail").sendKeys("muskaangupta099@gmail.com");
						}
						
						driver.findElement(By.id("com.techbins.niki.beta:id/btnSubmit")).click();
						
						
					}
					
					
					@Test(priority=5)
					public void callreceive() throws InterruptedException
					{
						if(driver.findElementsByXPath("//android.widget.LinearLayout[@index=1]//android.widget.TextView[@index=1]").size()>0)
						{
						System.out.println("Calling the number");	
						driver.findElementByXPath("//android.widget.LinearLayout[@index=1]//android.widget.TextView[@index=1]").click();
						Thread.sleep(10000);
						driver.navigate().back();
						}
						else
						{
							if(driver.findElementsById("com.techbins.niki.beta:id/txtCallTime").size()>0)
							{
								driver.findElementById("com.techbins.niki.beta:id/txtCallTime").click();
							}
							else
							{
								System.out.println("Some error occured");
							}
						}
						
					}
		
					@AfterTest
					public void End()
					{
						System.out.println("Closing app");
						driver.closeApp();
					}
					
	

}
